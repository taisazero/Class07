package com.example.zero.class07;

/**
 * Created by Zero on 10/23/2017.
 */

public class Music {

    String lImageURL;
    String sImageURL;
    String name;
    double price;

    public Music(){

    }

    public Music(String lImageURL, String sImageURL, String name, double price) {
        this.lImageURL = lImageURL;
        this.sImageURL = sImageURL;
        this.name = name;
        this.price = price;
    }

    public String getlImageURL() {
        return lImageURL;
    }

    public void setlImageURL(String lImageURL) {
        this.lImageURL = lImageURL;
    }

    public String getsImageURL() {
        return sImageURL;
    }

    public void setsImageURL(String sImageURL) {
        this.sImageURL = sImageURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
