package com.example.zero.class07;

import android.media.Image;
import android.support.annotation.MainThread;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Zero on 10/23/2017.
 */

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.ViewHolder>{


    ArrayList <Music>list;

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.music_item,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }
    public MusicAdapter(ArrayList<Music>l1){
        this.list=l1;

    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        double price;
        Music m= list.get(position);
        price=m.getPrice();
        holder.name.setText(m.getName());
        holder.del_btn.setImageResource(R.drawable.delete_icon);
        holder.price.setText("USD "+new Double(m.getPrice()).toString());
        if (price<=2.0 && price>0.0)
        holder.priceLevel.setImageResource(R.drawable.price_low);
        else if(price >2.0 && price<=6.0){
            holder.priceLevel.setImageResource(R.drawable.price_medium);

        }
        else if (price>6.0){
            holder.priceLevel.setImageResource(R.drawable.price_high);
        }
        Picasso.with(holder.itemView.getContext()).load(m.getlImageURL())
                .into( holder.largePic);

    }



    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView name;
        TextView price;
        ImageButton largePic;
        ImageButton priceLevel;
        ImageButton del_btn;
        public ViewHolder(View itemView) {

            super(itemView);

            name=(TextView)itemView.findViewById(R.id.nameView);
            price = (TextView) itemView.findViewById(R.id.priceView);
            priceLevel = (ImageButton)itemView.findViewById(R.id.priceLevel);
           largePic = (ImageButton) itemView.findViewById(R.id.largePic);
            del_btn = (ImageButton)itemView.findViewById(R.id.del_btn);
        }
    }


}
