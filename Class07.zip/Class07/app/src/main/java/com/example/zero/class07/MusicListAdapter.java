package com.example.zero.class07;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Zero on 10/23/2017.
 */

public class MusicListAdapter extends ArrayAdapter<Music> {

    Context context;
    ArrayList<Music> list;

    public MusicListAdapter(Context context, ArrayList<Music> musicArrayList) {
        super(context, R.layout.music_list_item, musicArrayList);
        this.context = context;
        this.list = musicArrayList;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.music_list_item, parent, false);
            holder = new ViewHolder();
            holder.smallPic = (ImageButton) convertView.findViewById(R.id.smallPic);
            holder.listPrice = (TextView) convertView.findViewById(R.id.listPrice);
            holder.listName = (TextView) convertView.findViewById(R.id.listName);
            holder.listPriceLevel = (ImageButton) convertView.findViewById(R.id.listPriceLevel);
            convertView.setTag(holder);

        }
        holder = (ViewHolder) convertView.getTag();
        TextView name = holder.listName;
        TextView price = holder.listPrice;
        ImageView pic = holder.smallPic;
        name.setText(list.get(position).getName());
        price.setText("USD "+new Double(list.get(position).getPrice()).toString());
        Picasso.with(convertView.getContext()).load(list.get(position).getsImageURL()).into(pic);






        return convertView;
    }

    public static class ViewHolder {
        ImageButton smallPic;
        TextView listName;
        TextView listPrice;
        ImageButton listPriceLevel;
    }

}


